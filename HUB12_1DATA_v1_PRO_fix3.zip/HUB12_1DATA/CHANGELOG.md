# Changelog

## 1.0.0
- Primera versión PRO: framebuffer, scan HUB12 1-DATA, auto-refresh estable, dirty-rect, clipping, marquesinas, fuentes DMD2, texto escalado, Print/cursor/printf.
